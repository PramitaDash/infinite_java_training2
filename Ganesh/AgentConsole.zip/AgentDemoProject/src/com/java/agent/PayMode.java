package com.java.agent;

public enum PayMode {
	MONTHLY, HALFYEARLY, YEARLY, QUARTERLY
}
