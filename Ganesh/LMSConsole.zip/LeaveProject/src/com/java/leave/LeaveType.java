package com.java.leave;

public enum LeaveType {
	EL, PL, ML

}
