package com.java.leave;

public enum LeaveStatus {
	PENDING, ACCEPTED, REJECTED

}
