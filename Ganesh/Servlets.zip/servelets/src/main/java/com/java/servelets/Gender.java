package com.java.servelets;



	public enum Gender {
		MALE, FEMALE
	}


