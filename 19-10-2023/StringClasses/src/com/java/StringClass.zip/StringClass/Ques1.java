package com.java.str;

public class Ques1 {
	  public static void main(String args[])
	  {
	    String n = "PRAMITA";
	    int l = n.length();
	    
//	    Returns the length of a specified string
	    for(int i = l-1;i>= 0;i--)
	    {
	      System.out.print (n.charAt(i));
	    }
	  }

}
