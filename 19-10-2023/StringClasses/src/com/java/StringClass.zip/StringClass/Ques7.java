package com.java.str;

public class Ques7 {
	
	public static void main(String args[]){  
		String name="what do you know about me";  
//		Checks whether a string contains a sequence of characters
		System.out.println(name.contains("do you know"));  
		System.out.println(name.contains("about"));  
		System.out.println(name.contains("hello"));  
		}

}
