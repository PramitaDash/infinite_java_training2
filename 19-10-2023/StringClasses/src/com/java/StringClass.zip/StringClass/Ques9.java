package com.java.str;

public class Ques9 {
	
	public static void main(String[] args) {
		String s = new String("Pramita");
		
//		Returns a new string which is the substring of a specified string
		System.out.println(s.subSequence(0, 3));
		System.out.println(s.subSequence(0, 6));
	}

}
