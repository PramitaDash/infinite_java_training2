package com.java.str;

public class Ques10 {
	
	public static void main(String[] args) {
	
		    String myStr1 = "Varanya";
		    String myStr2 = "";
//		    The isEmpty() method checks whether a string is empty or not.
		    System.out.println(myStr1.isEmpty());
		    System.out.println(myStr2.isEmpty());
		  }
		

}
