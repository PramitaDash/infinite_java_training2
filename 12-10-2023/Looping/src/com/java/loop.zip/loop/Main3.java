package com.java.loop;

public class Main3 {
	
	public static void main(String[] args) {
		
		//create an array
		int[] numbers = {3,7,5,-5};
		
		//iterating through the array
		for(int number:numbers) {
			System.out.println(number);
			
		}
	}

}
