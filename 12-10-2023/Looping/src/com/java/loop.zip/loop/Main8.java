// Java Program to display numbers from 1 to 5

package com.java.loop;

public class Main8 {

	 public static void main(String[] args) {

		    int i = 1, n = 5;

		    // do...while loop from 1 to 5
		    do {
		      System.out.println(i);
		      i++;
		    } while(i <= n);
		  }
		}

