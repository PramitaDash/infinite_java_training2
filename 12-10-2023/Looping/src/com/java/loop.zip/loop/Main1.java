
package com.java.loop;

public class Main1 {
	
	public static void main(String[] args) {
 
	for(int i=1;i<=5;i++){ 
		//It initializes an integer variable i to 1, 
		//and the loop continues as long as i is less than or equal to 3. 
	for(int j=1;j<=i;j++){ 
		//It initializes an integer variable j to 1, 
		//and the loop continues as long as j is less than or equal to 3
		System.out.print("* ");  
	}  
		System.out.println();//new line  
		
		}  
	}  
			

}
